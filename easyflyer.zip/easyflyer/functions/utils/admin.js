const admin = require("firebase-admin"); //import dependancies
//admin.initializeApp(); // initialize application

var serviceAccount = require("./permissions.json");
admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://easyflyer-d958b-default-rtdb.europe-west1.firebasedatabase.app"
});

//const db = admin.firestore(); //connect to database




module.exports = { db }; // export var db for any file to get access to it
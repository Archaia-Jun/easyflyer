const functions = require('firebase-functions'); //import packages

const app = require("express")(); //import express come along with firebase, and initialize it

const CART = require("./api/routes/cart"); //import cart file

app.use("/cart", CART) //server answer requests 

app.use(cors({ origin: true }));

//app.get('/hello-world', (req, res) => {
  //return res.status(200).send('Hello World!');
//});

exports.api = functions.region("europe-west1").https.onRequest(app); //exports functions

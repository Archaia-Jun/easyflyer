// Supprimer un cours
	exports.deleteCart = (req, res) => {
	  const document = cartRef.doc(req.params.idCart);
	  document
	    .get()
	    .then((doc) => {
	      if (!doc.exists) { //check if already exists, if not: catch error
	        return res.status(404).json({ error: "Cart not found" });
	      } else {
	        return document.delete();
	      }
	    })
	    .then(() => {
	      res.json({ message: "Cart deleted successfully" });
	    })
	    .catch((err) => {
	      console.error(err);
	      return res.status(500).json({ error: err.code });
	    });
	};
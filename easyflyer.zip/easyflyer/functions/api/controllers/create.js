// Create Cart
exports.create = (req, res) => { // 2 parameters  : request and response
    const newCart = { //var with data form requests
ecommerce_id: req.body.ecommerce_id, 
status: req.body.status,
customer_id: req.body.customer_id,
created_at: req.body.created_at,
updated_at: req.body.updated_at,

};

const { valid, errors } = validateCartData(newCart);
if (!valid) return res.status(400).json(errors); //data validation

cartRef
  .add(newCart)
  .then((doc) => {
    res.status(201).json({ message: `document ${doc.id} created successfully` });
  })
 // })
  .catch((err) => {
    res.status(500).json({ error: "something went wrong" }); //reply in json
    console.error(err);
  });
};
// Create Cart
exports.create = (req, res) => { // 2 parameters  : request and response
    const newCart = { //var with data form requests
name: req.body.name, 
fullProf: req.body.fullProf,
// typeRefund: req.body.typeRefund,
// nbrItems: req.body.nbrItems,
// totalPrice: req.body.totalPrice,
};

const { valid, errors } = validateCartData(newCart);
if (!valid) return res.status(400).json(errors); //data validation

cartRef
  .add(newCart)
  .then((doc) => {
    res.status(201).json({ message: `document ${doc.id} created successfully` });
  })
 // })
  .catch((err) => {
    res.status(500).json({ error: "something went wrong" }); //reply in json
    console.error(err);
  });
};
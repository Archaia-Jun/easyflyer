// Searching cart in database
	exports.getCart = (req, res) => {
	  const document = cartRef.doc(req.params.idCart);
	  document
	    .get()
	    .then((doc) => {
	      let cart = {
	        idCart: doc.id, //id of document
	        ...doc.data(), //data of document
	      };
	      return res.json(cours);
	    })
	    .catch((err) => console.error(err));
	};
// Add Cart details
	export function addCartDetails(req, res) {
    	  let cartDetails = reduceCartDetails(req.body); // import from validations/cart.js, check if request ins't empty and put it in cartDetails
	
	  const document = coursRef.doc(req.params.idCart); // data with idCart within collection cart in firebase
	  document
	    .update(cartDetails) //updating data
	    .then(() => {
	      return res.json({ message: "Details added succesfully" });
	    })
	    .catch((err) => { //catching errors
	      console.error(err);
	      return res.status(500).json({ error: err.code });
	    });
	}
const {
    validateCartData,
    reduceCartDetails,
  } = require("../validations/cart");
  const { db } = require("../../utils/admin"); //connect to database
  const cartRef = db.collection("cart"); 

  
             
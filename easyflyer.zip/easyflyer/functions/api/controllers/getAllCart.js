// Retrieve all cart in database
	exports.getAllCart = (req, res) => {
	  cartRef
	    .get()
	    .then((data) => {
	      let cart = [];
	      data.forEach((doc) => {
	        cart.push({
	          idCart: doc.id, //retrieve all cart by id
	          ...doc.data(),
	        });
	      });
	      return res.json(cours);
	    })
	    .catch((err) => console.error(err));
	};
const express = require("express"); //import server
const router = express.Router(); // for routing requests
const { 
    addCartDetails,
    create,
    getAllCart,
    getCart,
    deleteCart,
} = require("../controllers/cart"); //import functions from controllers folder


/* ENDPOINTS */

// get data of all cart
router.route("/").get(getAllCart); 
// get data of one cart
router.route("/id/:idCart").get(getCart);
// create new with post
router.route("/create").post(create);
// update with post
router.route("/update/:idCart").put(addCartDetails);
//delete 
router.route("/delete/:idCart").delete(deleteCart);

module.exports = router;
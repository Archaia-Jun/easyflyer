//Validator
const isEmpty = (string) => { //check if var is empty
    if (string.trim() === "") return true;
    else return false;
  };
  
  exports.validateCartData = (data) => {
    let errors = {};
    if (isEmpty(data.name)) errors.name = "Should have datas";
    if (isEmpty(data.fullProf)) errors.fullProf = "Should have datas";
    
    return {
      errors,
      valid: Object.keys(errors).length === 0 ? true : false,
    };
  };
  
  exports.reduceCartDetails = (data) => { //if fiefd is empty is not taken, if is populated data will be returned by cartDetails object
    let cartDetails = {};
    if (!isEmpty(data.name)) cartDetails.name = data.name;
    if (!isEmpty(data.description)) cartDetails.description = data.description;
   // if (!isEmpty(data.typeRefund)) cartDetails.typeExam = data.typeRefund;
   // if (!isEmpty(data.nbrItems)) cartDetails.nbrItems = data.nbrItems;
   // if (!isEmpty(data.totalPrice)) cartDetails.totalPrice = data.totalPrice;
    
    return cartDetails;
  };
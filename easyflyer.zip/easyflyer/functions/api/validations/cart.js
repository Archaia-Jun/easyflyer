//Validator
const isEmpty = (string) => { //check if var is empty
    if (string.trim() === "") return true;
    else return false;
  };
  
  exports.validateCartData = (data) => {
    let errors = {};
    if (isEmpty(data.ecommerce_id)) errors.ecommerce_id = "Should have datas";
    if (isEmpty(data.status)) errors.status = "Should have datas";
    if (isEmpty(data.customer_id)) errors.customer_id = "Should have datas";
    if (isEmpty(data.created_at)) errors.created_at = "Should have datas";
    if (isEmpty(data.updated_at)) errors.updated_at = "Should have datas";
    
    return {
      errors,
      valid: Object.keys(errors).length === 0 ? true : false,
    };
  };
  
  exports.reduceCartDetails = (data) => { //if fiefd is empty is not taken, if is populated data will be returned by cartDetails object
    let cartDetails = {};
    if (!isEmpty(data.ecommerce_id)) cartDetails.ecommerce_id = data.ecommerce_id;
    if (!isEmpty(data.status)) cartDetails.status = data.status;
    if (!isEmpty(data.customer_id)) cartDetails.customer_id = data.customer_id;
    if (!isEmpty(data.created_at)) cartDetails.created_at = data.created_at;
    if (!isEmpty(data.updated_at)) cartDetails.updated_at = data.updated_at;
    
    return cartDetails;
  };